export class BookedDetails
{
    roomCount:number;
    checkIn:string;
    checkOut:string;
    typeId:number;
}