export class roomType
{
    id:number;
    roomTypes:String;
}