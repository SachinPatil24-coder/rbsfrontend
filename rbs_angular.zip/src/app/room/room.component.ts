import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BookedDetails } from '../BookedDetails';
import { RoomerviceService } from '../roomservice.service';
import { Injectable } from '@angular/core';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']
})
export class RoomComponent implements OnInit {

  myGroup:FormGroup | any;
  room:BookedDetails;
  submitted = false;
  result1:Date;
  maxdate:string;
  mindate:string;

  constructor(private roomerviceServiceObj:RoomerviceService,private router:Router, private route:ActivatedRoute) {
    this.room=new BookedDetails;
   }
  

  ngOnInit(): void {
    var todayDate=new Date();
    this.mindate=todayDate.toISOString().slice(0, 10);
    this.result1 = this.addDays(30, todayDate);
    this.maxdate=this.result1.toISOString().slice(0, 10);
   
    this.myGroup=new FormGroup({
      roomCount:new FormControl('',[Validators.required]),
      checkIn:new FormControl('',[Validators.required]),
      checkOut:new FormControl('',[Validators.required])
      
    });
  
  }
   addDays(numOfDays: number, date = new Date()) {
    date.setDate(date.getDate() + numOfDays);
  
    return date;
  }
  bookRooms()
  {
    this.room.checkIn=this.myGroup.get("checkIn").value;
    this.room.checkOut=this.myGroup.get("checkOut").value;
    this.room.roomCount=this.myGroup.get("roomCount").value;
    this.room.typeId=4;
    console.log(this.room.checkIn);
    console.log(this.room.checkOut);
    console.log(this.room.roomCount);
    console.log(this.room.typeId);
    this.roomerviceServiceObj.bookRooms(this.room).subscribe(response => {
      console.log(response);
      this.submitted = true;
    },
    error => {
      console.log(error);
    });
  }
  

}
