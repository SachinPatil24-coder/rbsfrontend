import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs-compat/Observable';
import { BookedDetails } from './BookedDetails';

@Injectable({
  providedIn: 'root'
})
export class RoomerviceService {
private url:string='';
private status:string='';
  constructor(private http:HttpClient) {
    this.url="http://localhost:81";
   }
   public listAllUsers():Observable<BookedDetails[]>
   {
     return this.http.get<BookedDetails []>(this.url+"/getuserlist");
   }
   public bookRooms(objRoom:BookedDetails)
   {
    return this.http.post<BookedDetails>(this.url+"/addBookDetails",objRoom);
   }
}
